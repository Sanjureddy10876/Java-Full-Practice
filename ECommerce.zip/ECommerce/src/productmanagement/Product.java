package productmanagement;

public class Product{
	private int id;
	String name;
	double price;
	int stock;
	
	public Product(int id, String name, double price, int stock) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.stock = stock;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	@Override
	public boolean equals(Object obj) {
		Product product=(Product) obj;
		return this.id==product.id;
	}
	
	@Override
	public int hashCode() {
		
		return this.name.hashCode();
	}
	
	
}
