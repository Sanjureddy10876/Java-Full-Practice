package productmanagement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ListofProducts {

	static List<Product> products = Arrays.asList(new Product(1, "Laptop", 50000.0, 4),
			new Product(2, "Mobile", 10000.0, 4), new Product(3, "Mouse", 500.0, 4),
			new Product(4, "Charger", 1000.0, 4), new Product(4, "Charger", 1000.0, 4));

	static List<Product> filterProducts = products.stream().distinct().toList();

	Map<Product, Integer> cartList = new HashMap<>();

	public static void main(String[] args) {
		ListofProducts listofProducts = new ListofProducts();
		System.out.println("Welcome to ECommerce");
		System.out.println("Please select the Product");
		for (Product pro : filterProducts) {
			System.out.println(pro.getId() + " " + pro.name);
		}
		Scanner sc = new Scanner(System.in);
		int selectedOption;
		while (true) {
			selectedOption = sc.nextInt();
			switch (selectedOption) {
			case 1:
				listofProducts.cartList.put(new Product(1, "Laptop", 50000.0, 4), 1);
				break;

			case 2:
				listofProducts.cartList.put(new Product(2, "Mobile", 10000.0, 4), 1);
				break;

			case 3:
				listofProducts.cartList.put(new Product(3, "Mouse", 500.0, 4), 1);
				break;

			case 4:
				listofProducts.cartList.put(new Product(4, "Charger", 1000.0, 4), 1);
				break;

			case 5:
				System.out.println("This is yout cart");
//				cartList

			case 6:
				String search = sc.next();
				filterProducts = filterProducts.stream()
						.filter(n -> n.name.toLowerCase().contains(search.toLowerCase())).toList();
				for (Product product : filterProducts) {
					System.out.println(product.name);
				}
				break;
			case 7:
				filterProducts = filterProducts.stream().sorted(Comparator.comparing(Product::getPrice))
						.collect(Collectors.toList());
				for (Product product : filterProducts) {
					System.out.println(product.name);
				}
				break;
			case 8:
				filterProducts = filterProducts.stream().sorted(Comparator.comparing(Product::getPrice).reversed())
						.collect(Collectors.toList());
				for (Product product : filterProducts) {
					System.out.println(product.name);
				}
				break;
			}
			if (selectedOption == 10)
				break;
		}

	}
}
